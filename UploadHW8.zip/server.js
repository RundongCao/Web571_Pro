var express = require('express');
var bodyParser = require('body-parser')
var app = express();

var request = require('request');

var fs = require('fs'),
	xml2js = require('xml2js');
 
app.get('/', function (req, res) {
   res.header('Access-Control-Allow-Origin','*');
   console.log(req.query.symbol);

   var url = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=' + req.query.symbol + '&outputsize=full&apikey=KQS20D4CNURTYXU7';
   request(url, function(err,response,body){
   		if (!err) {
   			jsonobj = JSON.parse(body);
   			console.log('Done');
   			res.send(jsonobj);
   		}
   });

   //res.send('Hello World' + req.query.symbol);
   
})
 
var server = app.listen(8081, function () {
 
  var host = server.address().address
  var port = server.address().port
 
  console.log("应用实例，访问地址为 http://%s:%s", host, port)
 
})