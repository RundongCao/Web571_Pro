package com.example.crd.myfirstapp;

import android.net.Uri;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by CRD on 11/28/2017.
 */

public class Fragment3 extends Fragment {
    ListView tablenews;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_three,container,false);
        String symbol = getArguments().getString("Symbol");

        //String[] item = {"news1 Apple","news2 MSFT"};
        //ListView listView = (ListView) view.findViewById(R.id.mainMenu);
        //ArrayAdapter<String> listviewAdapter = new ArrayAdapter<String>(getActivity(),R.layout.mytextview,item);
        //listView.setAdapter(listviewAdapter);
        //final ListView tablenews = (ListView) getView().findViewById(R.id.mainMenu);

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        String url1 = "http://hw9server2-env.us-west-1.elasticbeanstalk.com/?symbol=" + symbol + "&indic=news1";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url1, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        CharSequence[] str5 = new CharSequence[response.length()];
                        for(int i = 0; i < response.length(); i++){
                            try {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                    str5[i] = Html.fromHtml(response.getString(i),Html.FROM_HTML_MODE_LEGACY);
                                }else {
                                    str5[i] = Html.fromHtml(response.getString(i));
                                }
                            } catch (JSONException e) {
                                str5[i] =  "";
                                e.printStackTrace();
                            }
                            //String[] str = response;
                        }
                        try{
                            //ArrayAdapter<String> adptertb = new ArrayAdapter<String>(getActivity(),R.layout.mytextview,str1);
                            tablenews = (ListView) getView().findViewById(R.id.mainMenu);
                            ArrayAdapter<CharSequence> adptertb2 = new ArrayAdapter<CharSequence>(getActivity(),R.layout.mytextview,str5);
                            tablenews.setAdapter(adptertb2);
                            tablenews.setClickable(true);

                            /*tablenews.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    String item = (String) tablenews.getItemAtPosition(position);
                                    Toast.makeText(getActivity(),item,Toast.LENGTH_SHORT).show();
                                }
                            });*/
                        }
                        catch (Exception e){
                            System.out.println("catch" + e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(getApplicationContext(), "Nothing", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        requestQueue.add(jsonArrayRequest);



        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}
