package com.example.crd.myfirstapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.FacebookSdk;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by CRD on 11/28/2017.
 */

public class Fragment1 extends Fragment{
    ImageButton button1;
    ImageButton button2;
    ProgressBar progressBar;
    String s1,s2,s3;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.frag_one,container,false);
        final String symbol = getArguments().getString("Symbol");
        progressBar = (ProgressBar) view.findViewById(R.id.pbar);
        progressBar.setVisibility(View.VISIBLE);


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        String url1 = "http://hw9server2-env.us-west-1.elasticbeanstalk.com/?symbol=" + symbol + "&indic=";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url1, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        String[] str2 = new String[response.length()];
                        for(int i = 0; i < response.length(); i++){
                            try {
                                str2[i] = response.getString(i);
                            } catch (JSONException e) {
                                str2[i] =  "";
                                e.printStackTrace();
                            }
                            //String[] str = response;
                        }
                        try{
                            List<Map<String,String>> listitem = new ArrayList<Map<String,String>>();
                            String[] str1 = new String[]{"Stock Symbol","Last Price","Change","Timestamp","Open","Close","Day's Range","Volume"};
                            //String[] str2 = new String[]{symbol,"Last Price2"};
                            for (int i = 0; i < str1.length; i++){
                                Map<String,String> item = new HashMap<String, String>();
                                item.put("header",str1[i]);
                                item.put("second",str2[i]);
                                listitem.add(item);
                            }
                            try{
                                s1 = str2[0];
                                s2 = str2[1];
                                s3 = str2[2];
                            }catch (Exception e){

                            }

                            //ArrayAdapter<String> adptertb = new ArrayAdapter<String>(getActivity(),R.layout.mytextview,str1);
                            ListView table1 = (ListView) getView().findViewById(R.id.list);
                            SimpleAdapter adptertb = new SimpleAdapter(getActivity(),listitem,R.layout.stocktable,new String[]{"header","second"},new int[]{R.id.tvF,R.id.tvS});
                            table1.setAdapter(adptertb);
                            progressBar.setVisibility(View.GONE);
                        }
                        catch (Exception e){
                            System.out.println("catch" + e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(getApplicationContext(), "Nothing", Toast.LENGTH_SHORT).show();
                    }
                }
        );/*{
                    @Override
                    protected Map<String,String> getParams() throws AuthFailureError{
                        Map<String,String> map = new HashMap<>();
                        map.put("symbol",valueAT.getText().toString());
                        return map;
                    }
                }*/
        requestQueue.add(jsonArrayRequest);

        button1 = (ImageButton) view.findViewById(R.id.imageButton);
        button1.setOnClickListener(imgbt1);
        button2 = (ImageButton) view.findViewById(R.id.imageButton2);
        button2.setOnClickListener(imgbt2);

        final WebView webView1 = (WebView) view.findViewById(R.id.chart1);
        webView1.getSettings().setJavaScriptEnabled(true);
        webView1.loadUrl("file:///android_asset/chart1.html");
        /*webView1.setWebViewClient(new WebViewClient(){
            public void onPageFinished(WebView v,String url){
                webView1.loadUrl("javascript:init('" + symbol + "')");
            }
        });*/

        ScrollView scrollView = (ScrollView) view.findViewById(R.id.sv1);
        scrollView.fullScroll(ScrollView.FOCUS_UP);
        return view;
    }

    View.OnClickListener imgbt1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            v.findViewById(R.id.imageButton).setBackgroundResource(R.drawable.filled);
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Favor",Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("sym1",s1);
            editor.putString("sym2",s2);
            editor.putString("sym3",s3);
            editor.apply();
        }
    };

    View.OnClickListener imgbt2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final ShareDialog shareDialog = new ShareDialog(getActivity());

            ShareLinkContent content = new ShareLinkContent.Builder().setContentUrl(Uri.parse("https://developers.facebook.com")).build();

            shareDialog.show(content);
        }
    };

    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
       // String[] DataTable = new String[]{"Stock Symbol","Last Price"};
       // ArrayAdapter adptertb = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,DataTable);
       // setListAdapter(adptertb);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //ListView table1 = (ListView) findViewById(R.id.table1);
       // ArrayAdapter adptertb = new ArrayAdapter(Fragment1.this,android.R.layout.simple_list_item_1,DataTable);
      //  table1.setAdapter(adptertb);
    }
}
