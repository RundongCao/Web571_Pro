package com.example.crd.myfirstapp;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by CRD on 11/28/2017.
 */

public class Fragment2 extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_two,container,false);
        final String symbol = getArguments().getString("Symbol");

        final WebView webView = (WebView) view.findViewById(R.id.chart2);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("file:///android_asset/chart2.html");
        webView.setWebViewClient(new WebViewClient(){
            public void onPageFinished(WebView v,String url){
               webView.loadUrl("javascript:init('" + symbol + "')");
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}
