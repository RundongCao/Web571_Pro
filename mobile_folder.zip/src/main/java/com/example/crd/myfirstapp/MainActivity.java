package com.example.crd.myfirstapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Button bt1,bt2;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = (Button) findViewById(R.id.button);
        bt2 = (Button) findViewById(R.id.button2);
        final AutoCompleteTextView valueAT = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);

        Spinner sort1 = (Spinner) findViewById(R.id.spinner);
        Spinner order1 = (Spinner) findViewById(R.id.spinner2);
        

        //final String[] str = new String[5];

        valueAT.addTextChangedListener(new TextWatcher(){
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count){

            }
            public void beforeTextChanged(CharSequence s, int start, int before, int count){

            }
            public void afterTextChanged(Editable s){
                RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);

                String url1 = "http://hw9server1-env.us-west-1.elasticbeanstalk.com/?symbol=" + valueAT.getText().toString();
                JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url1, null,
                        new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                String[] str = new String[response.length()];
                                for(int i = 0; i < response.length(); i++){
                                    try {
                                        str[i] = response.getString(i);
                                    } catch (JSONException e) {
                                        str[i] =  "";
                                        e.printStackTrace();
                                    }
                                    //String[] str = response;
                                }
                                try{
                                    ArrayAdapter adapter = new ArrayAdapter<String>(MainActivity.this,R.layout.mytextview,str);
                                    valueAT.setAdapter(adapter);
                                    valueAT.setThreshold(1);
                                }
                                catch (Exception e){
                                    System.out.println("catch" + e);
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(), "Nothing", Toast.LENGTH_SHORT).show();
                            }
                        }
                );/*{
                    @Override
                    protected Map<String,String> getParams() throws AuthFailureError{
                        Map<String,String> map = new HashMap<>();
                        map.put("symbol",valueAT.getText().toString());
                        return map;
                    }
                }*/
                requestQueue.add(jsonArrayRequest);

            }
        });

        //String[] str = {"AAPL","AAP"};



        //ed1 = (EditText) findViewById(R.id.editText);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (valueAT.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Please enter a stock name or symbol",Toast.LENGTH_LONG).show();
                }
                else{
                    sharedPreferences = getSharedPreferences("MySavedData", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("myValue",valueAT.getText().toString());
                    editor.apply();
                    Intent myIntent = new Intent(MainActivity.this, Main2Activity.class);
                    startActivity(myIntent);
                }

                //String symbol = ed1.getText().toString();
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valueAT.setText("");
            }
        });


        SharedPreferences resultPref = getSharedPreferences("Favor", Context.MODE_PRIVATE);
        String s1 = resultPref.getString("sym1","No result");
        String s2 = resultPref.getString("sym2","No result");
        String s3 = resultPref.getString("sym3","No result");
        if (s1!="No result"){
            List<Map<String,String>> listitem = new ArrayList<Map<String,String>>();
            //String[] str1 = new String[]{"Stock Symbol","Last Price","Change","Timestamp","Open","Close","Day's Range","Volume"};
            //String[] str2 = new String[]{symbol,"Last Price2"};

            Map<String,String> item = new HashMap<String, String>();
            item.put("header",s1);
            item.put("second",s2);
            item.put("third",s3);
            listitem.add(item);

            //ArrayAdapter<String> adptertb = new ArrayAdapter<String>(getActivity(),R.layout.mytextview,str1);
            ListView table1 = (ListView) findViewById(R.id.list1);
            SimpleAdapter adptertb = new SimpleAdapter(this,listitem,R.layout.favorlist,new String[]{"header","second","third"},new int[]{R.id.tv1,R.id.tv2,R.id.tv3});
            table1.setAdapter(adptertb);


        }

    }
}
