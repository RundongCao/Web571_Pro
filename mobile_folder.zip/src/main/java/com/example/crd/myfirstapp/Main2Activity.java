package com.example.crd.myfirstapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class  Main2Activity extends AppCompatActivity {

    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ImageButton backbtn1 = (ImageButton) findViewById(R.id.backbtn);
        TextView symbolDisplay = (TextView) findViewById(R.id.textView);

 //       TextView tv = (TextView) findViewById(R.id.tv);
//        tv.setMovementMethod(LinkMovementMethod.getInstance());

        SharedPreferences resultPref = getSharedPreferences("MySavedData", Context.MODE_PRIVATE);
        String symbol = resultPref.getString("myValue","No result");
        symbolDisplay.setText(symbol);

        backbtn1.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v){
               // Main2Activity.this.finish();//back
                Intent myIntent = new Intent(Main2Activity.this, MainActivity.class);
                startActivity(myIntent);
            }
        });

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));

    }



    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            Bundle bundle2 = new Bundle();
            SharedPreferences resultPref = getSharedPreferences("MySavedData", Context.MODE_PRIVATE);
            String symbol = resultPref.getString("myValue","No result");
            bundle2.putString("Symbol",symbol);
            switch (position){
                case 0:
                    Fragment1 fragment1 = new Fragment1();
                    fragment1.setArguments(bundle2);
                    return fragment1;
                case 1:
                    Fragment2 fragment2 = new Fragment2();
                    fragment2.setArguments(bundle2);
                    return fragment2;
                case 2:
                    Fragment3 fragment3 = new Fragment3();
                    fragment3.setArguments(bundle2);
                    return fragment3;
                default:
                    return null;
            }

        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }
    }
}
